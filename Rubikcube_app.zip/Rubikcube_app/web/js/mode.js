document.getElementById('go-startButton').addEventListener('click', function() {
    pywebview.api.go_to_start();
});

document.getElementById('easy').addEventListener('click', function() {
    pywebview.api.receive_mode("easy");
    pywebview.api.go_to_wait();
});

document.getElementById('normal').addEventListener('click', function() {
    pywebview.api.receive_mode("normal");
    pywebview.api.go_to_wait();
});

document.getElementById('hard').addEventListener('click', function() {
    pywebview.api.receive_mode("hard");
    pywebview.api.go_to_wait();
});

document.getElementById('extra').addEventListener('click', function() {
    pywebview.api.receive_mode("extra");
    pywebview.api.go_to_wait();
});