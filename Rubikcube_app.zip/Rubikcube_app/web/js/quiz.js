let timerDisplay = document.getElementById('timer');
let countDisplay = document.getElementById('count-display'); 
let startTime;
let timerInterval;
let lapTimes = []; // ラップタイムを保存する配列
let times = [];
let answers = [];

// タイマーを開始する関数
function startTimer() {
    startTime = Date.now();
    timerInterval = setInterval(updateTimer, 100); // 100ミリ秒ごとに更新
}

// タイマーを更新する関数
function updateTimer() {
    let elapsed = (Date.now() - startTime) / 1000; // 経過時間を秒で計算
    let minutes = Math.floor(elapsed / 60);
    let seconds = (elapsed % 60).toFixed(1); // 小数点以下2桁にフォーマット

    timerDisplay.textContent = 
        (minutes < 10 ? '0' : '') + minutes + ':' + 
        (seconds < 10 ? '0' : '') + seconds; // 秒数も2桁表示
}

// ラップタイムを記録する関数
function recordLapTime() {
    let elapsed = (Date.now() - startTime) / 1000; // 経過時間を秒で計算
    let minutes = Math.floor(elapsed / 60);
    let seconds = (elapsed % 60).toFixed(2); // 小数点以下2桁にフォーマット
    let lapTime = 
        (minutes < 10 ? '0' : '') + minutes + ':' + 
        (seconds < 10 ? '0' : '') + seconds; // 秒数も2桁表示
    times.push(elapsed)
    lapTimes.push(lapTime); // ラップタイムを配列に追加
    console.log("Lap Time:", lapTime); // コンソールに表示
}

async function reset() {
    recordLapTime(); // 現在のタイマーをラップタイムとして記録
    clearMatrix();
    await pywebview.api.matrix_reset();
    // タイマーはそのまま
}

window.onload = function() {
    start();
    startTimer(); // タイマー開始
}

function start() {
    if (window.pywebview) {
        loadMatrix();
    } else {
        setTimeout(start, 100);
    }
}

let count = 0;

function count_check() {
    if (count === 5) {
        setTimeout(() => {
            const textElement = document.querySelector('.text');
            textElement.style.display = 'block'; // 要素を表示
        }, 500);
        setTimeout(() => {
            pywebview.api.go_to_result();
        }, 1000);
    }
}

async function reset() {
    recordLapTime(); // 現在のタイマーをラップタイムとして記録
    if (count === 5) {
        pywebview.api.receive_result(lapTimes,answers);
    }
    clearMatrix();
    await pywebview.api.matrix_reset();
}

async function loadMatrix() {
    if (count < 5) {
        await pywebview.api.make();
        const json = await pywebview.api.get_matrix();
        const response = JSON.parse(json);
        console.log(response);
        displayMatrix(response);
    }
}

// 色のマッピングを更新
const colors = {
    0: 'transparent',
    1: 'white',
    2: 'orange',
    3: 'green',
    4: 'blue',
    5: 'red',
    6: 'yellow',
    7: 'black'
};

function displayMatrix(response) {
    const leftSquare = document.querySelector('.large-square:first-child .square-group');
    response.matrix.forEach(row => {
        row.forEach(value => {
            const squareWrapper = document.createElement('div');
            squareWrapper.className = 'square-wrapper-left';
            squareWrapper.style.backgroundColor = value !== 0 ? 'black' : 'transparent';

            const square = document.createElement('div');
            square.className = 'square-left';
            square.style.backgroundColor = colors[value] || "transparent";
            squareWrapper.style.border = value !== 0 ? "2px solid black" : "none";

            squareWrapper.appendChild(square);
            leftSquare.appendChild(squareWrapper);
        });
    });

    const rightSquares = document.querySelectorAll('.grid-container .large-square');
    const matrices = [response.matrix1, response.matrix2, response.matrix3, response.matrix4];

    rightSquares.forEach((rightSquare, index) => {
        const squareGroup = rightSquare.querySelector('.square-group');
        const matrix = matrices[index];

        matrix.forEach(row => {
            row.forEach(value => {
                const squareWrapper = document.createElement('div');
                squareWrapper.className = 'square-wrapper';
                squareWrapper.style.backgroundColor = value !== 0 ? 'black' : 'transparent';

                const square = document.createElement('div');
                square.className = 'square';
                square.style.backgroundColor = colors[value] || "transparent";
                squareWrapper.style.border = value !== 0 ? "2px solid black" : "none";

                squareWrapper.appendChild(square);
                squareGroup.appendChild(squareWrapper);
            });
        });
    });
}

function clearMatrix() {
    const leftSquare = document.querySelector('.large-square:first-child .square-group');
    leftSquare.innerHTML = '';

    const rightSquares = document.querySelectorAll('.grid-container .large-square');
    rightSquares.forEach(rightSquare => {
        const squareGroup = rightSquare.querySelector('.square-group');
        squareGroup.innerHTML = '';
    });
}

async function answer(flag) {
    let json = await pywebview.api.get_flag(flag);
    let response = JSON.parse(json);
    console.log(response);
    if (response.flag === "true") {
        await playSound_correct();
        document.querySelector('.outer-ring').style.display = 'block';
        document.querySelector('.inner-ring').style.display = 'block';
        answers.push("true");
        setTimeout(() => {
            document.querySelector('.outer-ring').style.display = 'none';
            document.querySelector('.inner-ring').style.display = 'none';
        }, 300);
    } else if (response.flag.includes("false")) {
        playSound_incorrect()
        const crossContainer = document.querySelector('.cross-container');
        crossContainer.style.display = 'flex';
        answers.push("false");
        setTimeout(() => {
            crossContainer.style.display = 'none';
        }, 300);
    }
}

async function playSound_correct() {
    const audio = document.getElementById('correctAudio');
    audio.play();
    
    // 0.5秒後に音声を停止
    setTimeout(() => {
        audio.pause();
        audio.currentTime = 0; // 再生位置を最初に戻す（必要であれば）
    }, 800); // 800ミリ秒 = 0.8秒
}

async function playSound_incorrect() {
    const audio = document.getElementById('incorrectAudio');
    audio.play();
    
    // 0.5秒後に音声を停止
    setTimeout(() => {
        audio.pause();
        audio.currentTime = 0; // 再生位置を最初に戻す（必要であれば）
    }, 800); // 800ミリ秒 = 0.8秒
}


const buttons = document.querySelectorAll(".grid-button");
buttons.forEach(button => {
    button.addEventListener("click", function() {
        count++;
        buttons.forEach(btn => btn.disabled = true);

        if (count < 5) {
            countDisplay.textContent = `${count+1}問目`; // Countを更新
            setTimeout(() => {
                buttons.forEach(btn => btn.disabled = false);
            }, 500);
        }
    });
});

const buttonElements = [1, 2, 3, 4];
buttonElements.forEach(num => {
    document.getElementById(num).addEventListener('click', async function() {
        await answer(num);
        count_check();
        await reset();
        await loadMatrix();
    });
});

document.getElementById('end').addEventListener('click', function() {
    pywebview.api.go_to_mode();
});

document.addEventListener('keydown', function(event) {
    if (event.code === 'Digit1') {
        event.preventDefault(); // スペースキーのデフォルト動作を防ぐ
        document.getElementById('1').click(); // ボタンをクリック
    }
});

document.addEventListener('keydown', function(event) {
    if (event.code === 'Digit2') {
        event.preventDefault(); // スペースキーのデフォルト動作を防ぐ
        document.getElementById('2').click(); // ボタンをクリック
    }
});

document.addEventListener('keydown', function(event) {
    if (event.code === 'Digit3') {
        event.preventDefault(); // スペースキーのデフォルト動作を防ぐ
        document.getElementById('3').click(); // ボタンをクリック
    }
});

document.addEventListener('keydown', function(event) {
    if (event.code === 'Digit4') {
        event.preventDefault(); // スペースキーのデフォルト動作を防ぐ
        document.getElementById('4').click(); // ボタンをクリック
    }
});