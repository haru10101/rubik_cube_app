document.addEventListener('click', function() {
    const textElement = document.getElementById('text');
    textElement.style.display = 'none'; // テキストを非表示にする
});

document.addEventListener('click', function() {
    let count = 3;
    const countdownElement = document.getElementById('countdown');
    
    countdownElement.textContent = count; // 初期値を表示

    const interval = setInterval(() => {
        count--;
        countdownElement.textContent = count; // カウントを更新

        if (count <= 0) {
            clearInterval(interval); // カウントダウンが終わったらクリア
            pywebview.api.start();
        }
    }, 1000); // 1秒ごとに実行
});

document.addEventListener('keydown', function(event) {
    if (event.code === 'Space') {
        event.preventDefault(); // スペースキーのデフォルト動作を防ぐ
        const textElement = document.getElementById('text');
        textElement.style.display = 'none'; // テキストを非表示にする
    }
});

document.addEventListener('keydown', function(event) {
    if (event.code === 'Space') {
        event.preventDefault(); // スペースキーのデフォルト動作を防ぐ
        let count = 3;
        const countdownElement = document.getElementById('countdown');
        
        countdownElement.textContent = count; // 初期値を表示

        const interval = setInterval(() => {
            count--;
            countdownElement.textContent = count; // カウントを更新

            if (count <= 0) {
                clearInterval(interval); // カウントダウンが終わったらクリア
                pywebview.api.start();
            }
        }, 1000); // 1秒ごとに実行
    }
});