document.getElementById('startButton').addEventListener('click', function() {
    window.pywebview.api.go_to_mode();
});

document.addEventListener('keydown', function(event) {
    if (event.code === 'Space') {
        event.preventDefault(); // スペースキーのデフォルト動作を防ぐ
        document.getElementById('startButton').click(); // ボタンをクリック
    }
});

document.getElementById('exitButton').addEventListener('click', function() {
    window.pywebview.api.close_window(); // ウィンドウを閉じる
});

document.addEventListener('keydown', function(event) {
    if (event.code === 'Escape') {
        event.preventDefault(); // エスケープキーのデフォルト動作を防ぐ
        document.getElementById('exitButton').click(); // ボタンをクリック
    }
});
