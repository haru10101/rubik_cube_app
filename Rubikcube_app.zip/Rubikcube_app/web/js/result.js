document.getElementById('go-startButton').addEventListener('click', function() {
    pywebview.api.go_to_start();
});

document.getElementById('go-modeButton').addEventListener('click', function() {
    window.pywebview.api.go_to_mode();
});

let times = [];
let truths = [];
let output = '';
let score = 0;

async function get_result() {
    if (window.pywebview) {
        const json1 = await pywebview.api.get_result();
        const response1 = JSON.parse(json1);
        const json2 = await pywebview.api.get_score();
        const response2 = JSON.parse(json2);
        times = response1.time;
        truths = response1.result;
        // scoreを整数に変換
        score = parseInt(response2.score, 10); // 10進数として変換

        console.log(times);
        console.log(truths);
        console.log(score);

        // truthsとtimesが更新された後に処理を実行
        displayResults();
    } else {
        setTimeout(get_result, 100);
    }
}

function displayResults() {
    output = ''; // 出力をリセット

    // スコアを表示
    output += `<div class="score-display">${score}</div>`; // スコアを追加

    for (let i = 0; i < truths.length; i++) {
        let symbol;
        if (truths[i] === 'true') {
            symbol = `<div class="circle"></div>`; // 輪を表示
        } else {
            symbol = `<div class="cross"></div>`; // バツを表示
        }
        output += `<div class="result-item">${symbol}<span class="question-text">${i + 1}問目</span> <span class="time-text">${times[i] || '00:00.00'}</span></div>`;
    }

    document.getElementById('output').innerHTML = output; // 出力を更新
}

window.onload = function() {
    get_result();
}
