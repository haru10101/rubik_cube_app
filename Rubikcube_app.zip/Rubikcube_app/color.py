import random

color_array1 = ["lightgray","white","orange","green","blue","red","yellow"]
color_array2 = ["lightgray","orange","yellow","green","blue","white","red"]
color_array3 = ["lightgray","yellow","red","green","blue","orange","white"]
color_array4 = ["lightgray","red","white","green","blue","yellow","orange"]
color_array5 = ["lightgray","white","green","red","orange","blue","yellow"]
color_array6 = ["lightgray","green","yellow","red","orange","white","blue"]
color_array7 = ["lightgray","yellow","blue","red","orange","green","white"]
color_array8 = ["lightgray","blue","white","red","orange","yellow","green"]
color_array9 = ["lightgray","white","red","blue","green","orange","yellow"]
color_array10 = ["lightgray","red","yellow","blue","green","white","orange"]
color_array11 = ["lightgray","yellow","orange","blue","green","red","white"]
color_array12 = ["lightgray","orange","white","blue","green","yellow","red"]
color_array13 = ["lightgray","white","blue","orange","red","green","yellow"]
color_array14 = ["lightgray","blue","yellow","orange","red","white","green"]
color_array15 = ["lightgray","yellow","green","orange","red","blue","white"]
color_array16 = ["lightgray","green","white","orange","red","yellow","blue"]
color_array17 = ["lightgray","blue","orange","white","yellow","red","green"]
color_array18 = ["lightgray","orange","green","white","yellow","blue","red"]
color_array19 = ["lightgray","green","red","white","yellow","orange","blue"]
color_array20 = ["lightgray","red","blue","white","yellow","green","orange"]
color_array21 = ["lightgray","blue","red","yellow","white","orange","green"]
color_array22 = ["lightgray","red","green","yellow","white","blue","orange"]
color_array23 = ["lightgray","green","orange","yellow","white","red","blue"]
color_array24 = ["lightgray","orange","blue","yellow","white","green","red"]

color_array = [
    color_array1,
    color_array2,
    color_array3,
    color_array4,
    color_array5,
    color_array6,
    color_array7,
    color_array8,
    color_array9,
    color_array10,
    color_array11,
    color_array12,
    color_array13,
    color_array14,
    color_array15,
    color_array16,
    color_array17,
    color_array18,
    color_array19,
    color_array20,
    color_array21,
    color_array22,
    color_array23,
    color_array24
]

def getColor(excption=[],index="turu"):
    if index == "false":
        color_array.remove(excption)
    return random.choice(color_array)

if __name__ == "__main__":
    print(getColor())
