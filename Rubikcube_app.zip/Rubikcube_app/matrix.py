import math
import random
import copy
import numpy as np
import color
import geometric
#クラス
class Rubik:
    #インスタンス 10の位：色 1の位：位置
    def __init__(self,matrix = [
            [0,0,0,   12,19,18,   0,0,0,   0,0,0],
            [0,0,0,   14,15,16,   0,0,0,   0,0,0],
            [0,0,0,   11,17,13,   0,0,0,   0,0,0],

            [22,23,21,   31,32,33,   53,52,58,   48,43,42],
            [29,25,24,   34,35,36,   56,55,57,   47,45,49],
            [26,28,27,   37,38,39,   59,51,54,   44,41,46],

            [0,0,0,   67,68,69,   0,0,0,   0,0,0],
            [0,0,0,   62,65,61,   0,0,0,   0,0,0],
            [0,0,0,   66,68,64,   0,0,0,   0,0,0],

            [0,0,0,   0,0,0,   0,0,0,   0,0,0],
            [0,0,0,   0,0,0,   0,0,0,   0,0,0],
            [0,0,0,   0,0,0,   0,0,0,   0,0,0],
        ],rotated = []):
        #メイン：回転操作を行う、内部の処理
        self.matrix_3 = matrix
        #サブ：変更された展開図、描画される
        self.matrix_3_sub = [
            [0,0,0,   1,1,1,   0,0,0,   0,0,0],
            [0,0,0,   1,1,1,   0,0,0,   0,0,0],
            [0,0,0,   1,1,1,   0,0,0,   0,0,0],

            [2,2,2,   3,3,3,   5,5,5,   4,4,4],
            [2,2,2,   3,3,3,   5,5,5,   4,4,4],
            [2,2,2,   3,3,3,   5,5,5,   4,4,4],

            [0,0,0,   6,6,6,   0,0,0,   0,0,0],
            [0,0,0,   6,6,6,   0,0,0,   0,0,0],
            [0,0,0,   6,6,6,   0,0,0,   0,0,0],

            [0,0,0,   0,0,0,   0,0,0,   0,0,0],
            [0,0,0,   0,0,0,   0,0,0,   0,0,0],
            [0,0,0,   0,0,0,   0,0,0,   0,0,0],
        ]
        #初期配置
        self.matrix_3_def = [
            [0,0,0,   12,19,18,   0,0,0,   0,0,0],
            [0,0,0,   14,15,16,   0,0,0,   0,0,0],
            [0,0,0,   11,17,13,   0,0,0,   0,0,0],

            [22,23,21,   31,32,33,   53,52,58,   48,43,42],
            [29,25,24,   34,35,36,   56,55,57,   47,45,49],
            [26,28,27,   37,38,39,   59,51,54,   44,41,46],

            [0,0,0,   67,68,69,   0,0,0,   0,0,0],
            [0,0,0,   62,65,61,   0,0,0,   0,0,0],
            [0,0,0,   66,68,64,   0,0,0,   0,0,0],

            [0,0,0,   0,0,0,   0,0,0,   0,0,0],
            [0,0,0,   0,0,0,   0,0,0,   0,0,0],
            [0,0,0,   0,0,0,   0,0,0,   0,0,0],
        ]
        
        self.matrix_3_sub_def = [
            [0,0,0,   1,1,1,   0,0,0,   0,0,0],
            [0,0,0,   1,1,1,   0,0,0,   0,0,0],
            [0,0,0,   1,1,1,   0,0,0,   0,0,0],

            [2,2,2,   3,3,3,   5,5,5,   4,4,4],
            [2,2,2,   3,3,3,   5,5,5,   4,4,4],
            [2,2,2,   3,3,3,   5,5,5,   4,4,4],

            [0,0,0,   6,6,6,   0,0,0,   0,0,0],
            [0,0,0,   6,6,6,   0,0,0,   0,0,0],
            [0,0,0,   6,6,6,   0,0,0,   0,0,0],

            [0,0,0,   0,0,0,   0,0,0,   0,0,0],
            [0,0,0,   0,0,0,   0,0,0,   0,0,0],
            [0,0,0,   0,0,0,   0,0,0,   0,0,0],
        ]
        
        #初期の展開図
        self.geometric_net = geometric.get_geometric(0)
        
        
        #色情報
        self.color_array = color.getColor()
        
        #正誤
        self.flag = "true"
        
        #回転履歴
        self.rotated = rotated
    
    #指定した3X3面の配置を返す
    def get3x3(self,x,y):
        array = [
            [self.matrix_3[3*x][3*y],self.matrix_3[3*x][3*y+1],self.matrix_3[3*x][3*y+2]],
            [self.matrix_3[3*x+1][3*y],self.matrix_3[3*x+1][3*y+1],self.matrix_3[3*x+1][3*y+2]],
            [self.matrix_3[3*x+2][3*y],self.matrix_3[3*x+2][3*y+1],self.matrix_3[3*x+2][3*y+2]]
        ]
        return array
    #指定した3X3面に配置する
    def put3x3(self,x,y,array):
        for i in range(3):
            for j in range(3):
                self.matrix_3[3*x+i][3*y+j] = array[i][j]
    #指定した3X3面の配置を返す【サブ】
    def get3x3_sub(self,x,y):
        array = [
            [self.matrix_3_sub[3*x][3*y],self.matrix_3_sub[3*x][3*y+1],self.matrix_3_sub[3*x][3*y+2]],
            [self.matrix_3_sub[3*x+1][3*y],self.matrix_3_sub[3*x+1][3*y+1],self.matrix_3_sub[3*x+1][3*y+2]],
            [self.matrix_3_sub[3*x+2][3*y],self.matrix_3_sub[3*x+2][3*y+1],self.matrix_3_sub[3*x+2][3*y+2]]
        ]
        return array
    #指定した3X3面に配置する 【サブ】
    def put3x3_sub(self,x,y,array):
        for i in range(3):
            for j in range(3):
                self.matrix_3_sub[3*x+i][3*y+j] = array[i][j]
    #指定した3X3面の配置を返す【初期】
    def get3x3_def(self,x,y):
        array = [
            [self.matrix_3_def[3*x][3*y],self.matrix_3_def[3*x][3*y+1],self.matrix_3_def[3*x][3*y+2]],
            [self.matrix_3_def[3*x+1][3*y],self.matrix_3_def[3*x+1][3*y+1],self.matrix_3_def[3*x+1][3*y+2]],
            [self.matrix_3_def[3*x+2][3*y],self.matrix_3_def[3*x+2][3*y+1],self.matrix_3_def[3*x+2][3*y+2]]
        ]
        return array
    
    #色をセット
    def putColor(self,color_put,index = "turu"):
        if index == "turu":
            self.color_array = color_put
        elif index in "false":
            self.color_array = color.getColor(excption=color_put, index="false")
    def set_flag(self,flag):
        self.flag = flag
    
    #右回転
    def rotate_right(self,array):
        array1 = [[0]*3 for _ in range(3)]
        
        for i in range(3):
            for j in range(3):
                array1[j][2-i] = array[i][j]
        return array1
    #左回転
    def rotate_left(self,array):
        array1 = [[0]*3 for _ in range(3)]

        for i in range(3):
            for j in range(3):
                array1[2-j][i] = array[i][j]
        return array1
    
    def reset_matrix(self):
        self.matrix_3 = copy.deepcopy(self.matrix_3_def)
        self.matrix_3_sub = copy.deepcopy(self.matrix_3_sub_def)
        self.rotated = [] 

    #キューブの1行または1列を回転させたときの処理関数
    #direction: 回転の方向（X+,X-,Y-,Y+,Z+,Z-)
    #index: 各面におて回転させた行または列の場所（0,1,2）
    #margin: 4x4の展開図において回転する面の位置（0,1,2,3）2次元配列で考える際に必要
    #X+とX-の場合、indexはrow
    #Y-とY+の場合、indexはcolumn
    def rotate(self,direction, index, x, y):
        #print(direction,index)
        if direction == "X+":
            margin = 3*x
            
            temp = [self.matrix_3[margin+index][9],self.matrix_3[margin+index][10],self.matrix_3[margin+index][11]]
            for j in range(11,2,-3):
                self.matrix_3[margin+index][j] = self.matrix_3[margin+index][j-3]
                self.matrix_3[margin+index][j-1] = self.matrix_3[margin+index][j-4]
                self.matrix_3[margin+index][j-2] = self.matrix_3[margin+index][j-5]
            self.matrix_3[margin+index][2] = temp[2]
            self.matrix_3[margin+index][1] = temp[1]
            self.matrix_3[margin+index][0] = temp[0]
            if index == 0:
                temp0 = self.get3x3(0,1)
                temp1 = self.rotate_left(temp0)
                self.put3x3(0,1,temp1)
            elif index == 2:
                temp0 = self.get3x3(2,1)
                temp1 = self.rotate_right(temp0)
                self.put3x3(2,1,temp1)
        
        
        elif direction == "X-":
            margin = 3*x
            
            temp = [self.matrix_3[margin+index][0],self.matrix_3[margin+index][1],self.matrix_3[margin+index][2]]
            for j in range(0,9,3):
                self.matrix_3[margin+index][j] = self.matrix_3[margin+index][j+3]
                self.matrix_3[margin+index][j+1] = self.matrix_3[margin+index][j+4]
                self.matrix_3[margin+index][j+2] = self.matrix_3[margin+index][j+5]
            self.matrix_3[margin+index][11] = temp[2]
            self.matrix_3[margin+index][10] = temp[1]
            self.matrix_3[margin+index][9] = temp[0]
            if index == 0:
                temp0 = self.get3x3(0,1)
                temp1 = self.rotate_right(temp0)
                self.put3x3(0,1,temp1)
            elif index == 2:
                temp0 = self.get3x3(2,1)
                temp1 = self.rotate_left(temp0)
                self.put3x3(2,1,temp1)
        
        
        elif direction == "Y+":
            margin = 3*y
            
            temp = [self.matrix_3[0][margin+index],self.matrix_3[1][margin+index],self.matrix_3[2][margin+index]]
            for i in range(0,9,3):
                self.matrix_3[i][margin+index] = self.matrix_3[i+3][margin+index]
                self.matrix_3[i+1][margin+index] = self.matrix_3[i+4][margin+index]
                self.matrix_3[i+2][margin+index] = self.matrix_3[i+5][margin+index]
            
            self.matrix_3[6][margin+index] = self.matrix_3[5][margin+8-index]
            self.matrix_3[7][margin+index] = self.matrix_3[4][margin+8-index]
            self.matrix_3[8][margin+index] = self.matrix_3[3][margin+8-index]
            
            self.matrix_3[3][margin+8-index] = temp[2]
            self.matrix_3[4][margin+8-index] = temp[1]
            self.matrix_3[5][margin+8-index] = temp[0]
            
            if index == 0:
                temp0 = self.get3x3(1,0)
                temp1 = self.rotate_left(temp0)
                self.put3x3(1,0,temp1)
            elif index == 2:
                temp0 = self.get3x3(1,2)
                temp1 = self.rotate_right(temp0)
                self.put3x3(1,2,temp1)
        
        
        elif direction == "Y-":
            margin = 3*y
            temp = [self.matrix_3[6][margin+index],self.matrix_3[7][margin+index],self.matrix_3[8][margin+index]]
            for i in range(8,2,-3):
                self.matrix_3[i][margin+index] = self.matrix_3[i-3][margin+index]
                self.matrix_3[i-1][margin+index] = self.matrix_3[i-4][margin+index]
                self.matrix_3[i-2][margin+index] = self.matrix_3[i-5][margin+index]
            
            self.matrix_3[2][margin+index] = self.matrix_3[3][margin+8-index]
            self.matrix_3[1][margin+index] = self.matrix_3[4][margin+8-index]
            self.matrix_3[0][margin+index] = self.matrix_3[5][margin+8-index]
            
            self.matrix_3[3][margin+8-index] = temp[2]
            self.matrix_3[4][margin+8-index] = temp[1]
            self.matrix_3[5][margin+8-index] = temp[0]
            
            if index == 0:
                temp0 = self.get3x3(1,0)
                temp1 = self.rotate_right(temp0)
                self.put3x3(1,0,temp1)
            elif index == 2:
                temp0 = self.get3x3(1,2)
                temp1 = self.rotate_left(temp0)
                self.put3x3(1,2,temp1)
        
        
        elif direction == "Z+":
            temp = [self.matrix_3[index][3],self.matrix_3[index][4],self.matrix_3[index][5]]
            self.matrix_3[index][3] = self.matrix_3[5][index]
            self.matrix_3[index][4] = self.matrix_3[4][index]
            self.matrix_3[index][5] = self.matrix_3[3][index]
            
            self.matrix_3[3][index] = self.matrix_3[8-index][3]
            self.matrix_3[4][index] = self.matrix_3[8-index][4]
            self.matrix_3[5][index] = self.matrix_3[8-index][5]
            
            self.matrix_3[8-index][3] = self.matrix_3[5][8-index]
            self.matrix_3[8-index][4] = self.matrix_3[4][8-index]
            self.matrix_3[8-index][5] = self.matrix_3[3][8-index]
            
            self.matrix_3[3][8-index] = temp[0]
            self.matrix_3[4][8-index] = temp[1]
            self.matrix_3[5][8-index] = temp[2]
        
            if index == 0:
                temp0 = self.get3x3(1,3)
                temp1 = self.rotate_left(temp0)
                self.put3x3(1,3,temp1)
            elif index == 2:
                temp0 = self.get3x3(1,1)
                temp1 = self.rotate_right(temp0)
                self.put3x3(1,1,temp1)
        
        elif direction == "Z-":
            temp = [self.matrix_3[index][3],self.matrix_3[index][4],self.matrix_3[index][5]]
            self.matrix_3[index][3] = self.matrix_3[3][8-index] 
            self.matrix_3[index][4] = self.matrix_3[4][8-index] 
            self.matrix_3[index][5] = self.matrix_3[5][8-index] 
            
            self.matrix_3[3][8-index] = self.matrix_3[8-index][5] 
            self.matrix_3[4][8-index] = self.matrix_3[8-index][4] 
            self.matrix_3[5][8-index] = self.matrix_3[8-index][3]
            
            self.matrix_3[8-index][3] = self.matrix_3[3][index]
            self.matrix_3[8-index][4] = self.matrix_3[4][index]
            self.matrix_3[8-index][5] = self.matrix_3[5][index]
            
            self.matrix_3[3][index] = temp[2]
            self.matrix_3[4][index] = temp[1]
            self.matrix_3[5][index] = temp[0]
            
            if index == 0:
                temp0 = self.get3x3(1,3)
                temp1 = self.rotate_right(temp0)
                self.put3x3(1,3,temp1)
            elif index == 2:
                temp0 = self.get3x3(1,1)
                temp1 = self.rotate_left(temp0)
                self.put3x3(1,1,temp1)
        
        else:
            print("ERROR")
        
    def reverse_direction(self,direction=""):
        if "+" in direction:
            return direction.replace("+", "-")
        elif "-" in direction:
            return direction.replace("-", "+")
        
    def reverse_directions(self,directions=[]):
        reversed_directions = []
        for i in range(len(directions)):
            reversed_directions.append(self.reverse_direction(copy.deepcopy(directions[i])))
        return reversed_directions
        
    def shaffuru_matrix(self,count=0,excption=[]):
        directions = ["X0+","X1+","X2+","X0-","X1-","X2-","Y0+","Y1+","Y2+","Y0-","Y1-","Y2-","Z0+","Z1+","Z2+","Z0-","Z1-","Z2-"]
        directions = [item for item in directions if item not in excption]
        for i in range(count):
            directions_temp = directions
            if self.rotated:
                directions_temp = [item for item in directions if item not in self.reverse_direction(copy.copy(self.rotated[-1]))]
            direction = random.choice(directions_temp)
            if direction == "X0+":
                self.rotate("X+",0,1,1)
            elif direction == "X1+":
                self.rotate("X+",1,1,1)
            elif direction == "X2+":
                self.rotate("X+",2,1,1)
            elif direction == "X0-":
                self.rotate("X-",0,1,1)
            elif direction == "X1-":
                self.rotate("X-",1,1,1)
            elif direction == "X2-":
                self.rotate("X-",2,1,1)
            elif direction == "Y0+":
                self.rotate("Y+",0,1,1)
            elif direction == "Y1+":
                self.rotate("Y+",1,1,1)
            elif direction == "Y2+":
                self.rotate("Y+",2,1,1)
            elif direction == "Y0-":
                self.rotate("Y-",0,1,1)
            elif direction == "Y1-":
                self.rotate("Y-",1,1,1)
            elif direction == "Y2-":
                self.rotate("Y-",2,1,1)
            elif direction == "Z0+":
                self.rotate("Z+",0,0,1)
            elif direction == "Z1+":
                self.rotate("Z+",1,0,1)
            elif direction == "Z2+":
                self.rotate("Z+",2,0,1)
            elif direction == "Z0-":
                self.rotate("Z-",0,0,1)
            elif direction == "Z1-":
                self.rotate("Z-",1,0,1)
            elif direction == "Z2-":
                self.rotate("Z-",2,0,1)
            self.rotated.append(direction)
        #print(self.rotated)
        for i in range(12):
            for j in range(12):
                self.matrix_3_sub[i][j] = math.floor(self.matrix_3[i][j]/10)
        #print_matrix(self.matrix_3_sub)
        #print(count,"a")
        
    def rotate_matrix(self,directions=[]):
        for i in range(len(directions)):
            direction = str(directions[i])
            if direction == "X0+":
                self.rotate("X+",0,1,1)
            elif direction == "X1+":
                self.rotate("X+",1,1,1)
            elif direction == "X2+":
                self.rotate("X+",2,1,1)
            elif direction == "X0-":
                self.rotate("X-",0,1,1)
            elif direction == "X1-":
                self.rotate("X-",1,1,1)
            elif direction == "X2-":
                self.rotate("X-",2,1,1)
            elif direction == "Y0+":
                self.rotate("Y+",0,1,1)
            elif direction == "Y1+":
                self.rotate("Y+",1,1,1)
            elif direction == "Y2+":
                self.rotate("Y+",2,1,1)
            elif direction == "Y0-":
                self.rotate("Y-",0,1,1)
            elif direction == "Y1-":
                self.rotate("Y-",1,1,1)
            elif direction == "Y2-":
                self.rotate("Y-",2,1,1)
            elif direction == "Z0+":
                self.rotate("Z+",0,0,1)
            elif direction == "Z1+":
                self.rotate("Z+",1,0,1)
            elif direction == "Z2+":
                self.rotate("Z+",2,0,1)
            elif direction == "Z0-":
                self.rotate("Z+",0,0,1)
            elif direction == "Z1-":
                self.rotate("Z+",1,0,1)
            elif direction == "Z2+":
                self.rotate("Z+",2,0,1)
            self.rotated.append(direction)
            
        for i in range(12):
            for j in range(12):
                self.matrix_3_sub[i][j] = math.floor(self.matrix_3[i][j]/10)
        
    def change_matrix(self,geometric_net_new="None",excption=[]):
        if geometric_net_new == "None":
            geometric_net_new = geometric.random_geometric(excption)
        zero_matrix = [[0]*4 for _ in range(4)]
        for i in range(4):
            for j in range(4):
                if geometric_net_new[i][j] == 0:
                    self.put3x3_sub(i,j,zero_matrix)
                    continue
                for w in range(4):
                    for h in range(4):
                        if self.geometric_net[h][w] == geometric_net_new[i][j]:
                            self.put3x3_sub(i,j,self.get3x3(h,w))
        self.geometric_net = geometric_net_new
        self.consistency()
        for i in range(12):
            for j in range(12):
                self.matrix_3_sub[i][j] = math.floor(self.matrix_3_sub[i][j]/10)
        
    def change_matrix2(self,geometric_net_new="None",excption=[]):
        if geometric_net_new == "None":
            geometric_net_new = geometric.random_geometric2(excption)
        zero_matrix = [[0]*4 for _ in range(4)]
        for i in range(4):
            for j in range(4):
                if geometric_net_new[i][j] == 0:
                    self.put3x3_sub(i,j,zero_matrix)
                    continue
                for w in range(4):
                    for h in range(4):
                        if self.geometric_net[h][w] == geometric_net_new[i][j]:
                            self.put3x3_sub(i,j,self.get3x3(h,w))
        self.geometric_net = geometric_net_new
        self.consistency()
        for i in range(12):
            for j in range(12):
                self.matrix_3_sub[i][j] = math.floor(self.matrix_3_sub[i][j]/10)
    
    #ルービックキューブの整合性をとる
    def consistency(self):
        array_edge = [[0]*4 for _ in range(4) ]
        for i in range(3):
            for j in range(3):
                array1 = self.get3x3_sub(i,j)
                array2 = self.get3x3_sub(i,j+1)
                array3 = self.get3x3_sub(i+1,j)
                array4 = self.get3x3_sub(i+1,j+1)
                array_edge[0] = set(np.mod([array1[0][0],array1[0][2],array1[2][0],array1[2][2]],10))
                array_edge[1] = set(np.mod([array2[0][0],array2[0][2],array2[2][0],array2[2][2]],10))
                array_edge[2] = set(np.mod([array3[0][0],array3[0][2],array3[2][0],array3[2][2]],10))
                array_edge[3] = set(np.mod([array4[0][0],array4[0][2],array4[2][0],array4[2][2]],10))
                for k in range(4):
                    if 0 in array_edge[k]:
                        array_edge[k] = set(array_edge[k]).union({1,2,3,4,5,6,7,8,9})
                edge = array_edge[0]&array_edge[1]&array_edge[2]&array_edge[3]
                edge = list(edge)
                if 0 in edge or len(edge) == 4:
                    continue
#                print(edge)
#                for x in array1:
#                    print(x)
#                for x in array2:
#                    print(x)
#                for x in array3:
#                    print(x)
#                for x in array4:
#                    print(x)
                if array1[0][0] != 0:
                    if np.mod(array1[0][0],10) == edge[0]:
                        array1 = self.rotate_right(self.rotate_right(array1))
                    elif np.mod(array1[0][2],10) == edge[0]:
                        array1 = self.rotate_right(array1)
                    elif np.mod(array1[2][0],10) == edge[0]:
                        array1 = self.rotate_left(array1)
                if array2[0][0] != 0:
                    if np.mod(array2[0][0],10) == edge[0]:
                        array2 = self.rotate_left(array2)
                    elif np.mod(array2[0][2],10) == edge[0]:
                        array2 = self.rotate_left(self.rotate_left(array2))
                    elif np.mod(array2[2][2],10) == edge[0]:
                        array2 = self.rotate_right(array2)
                if array3[0][0] != 0:
                    if np.mod(array3[0][0],10) == edge[0]:
                        array3 = self.rotate_right(array3)
                    elif np.mod(array3[2][0],10) == edge[0]:
                        array3 = self.rotate_right(self.rotate_right(array3))
                    elif np.mod(array3[2][2],10) == edge[0]:
                        array3 = self.rotate_left(array3)
                if array4[0][0] != 0:
                    if np.mod(array4[0][2],10) == edge[0]:
                        array4 = self.rotate_left(array4)
                    elif np.mod(array4[2][0],10) == edge[0]:
                        array4 = self.rotate_right(array4)
                    elif np.mod(array4[2][2],10) == edge[0]:
                        array4 = self.rotate_left(self.rotate_left(array4))
                if len(edge) == 1 and (np.mod(array1[2][2],10) == np.mod(array2[2][0],10) 
                    or array1[0][0] == 0 or array2[0][0] == 0) and (np.mod(array1[2][2],10) == np.mod(array3[0][2],10)
                    or array1[0][0] == 0 or array3[0][0] == 0) and (np.mod(array2[2][0],10) == np.mod(array4[0][0],10)
                    or array2[0][0] == 0 or array4[0][0] == 0) and (np.mod(array3[0][2],10) == np.mod(array4[0][0],10)
                    or array3[0][0] == 0 or array4[0][0] == 0):
                    self.put3x3_sub(i,j,array1)
                    self.put3x3_sub(i,j+1,array2)
                    self.put3x3_sub(i+1,j,array3)
                    self.put3x3_sub(i+1,j+1,array4)
                elif len(edge) == 2:
                    if (np.mod(array1[2][2],10) == np.mod(array2[2][0],10) 
                        or array1[0][0] == 0 or array2[0][0] == 0) and (np.mod(array1[2][2],10) == np.mod(array3[0][2],10)
                        or array1[0][0] == 0 or array3[0][0] == 0) and (np.mod(array2[2][0],10) == np.mod(array4[0][0],10)
                        or array2[0][0] == 0 or array4[0][0] == 0) and (np.mod(array3[0][2],10) == np.mod(array4[0][0],10)
                        or array3[0][0] == 0 or array4[0][0] == 0) and (np.mod(array1[0][2],10) == np.mod(array2[0][0],10) 
                        or array1[0][0] == 0 or array2[0][0] == 0) and (np.mod(array1[2][0],10) == np.mod(array3[0][0],10)
                        or array1[0][0] == 0 or array3[0][0] == 0) and (np.mod(array2[2][2],10) == np.mod(array4[0][2],10)
                        or array2[0][0] == 0 or array4[0][0] == 0) and (np.mod(array3[2][2],10) == np.mod(array4[2][0],10)
                        or array3[0][0] == 0 or array4[0][0] == 0):
                        self.put3x3_sub(i,j,array1)
                        self.put3x3_sub(i,j+1,array2)
                        self.put3x3_sub(i+1,j,array3)
                        self.put3x3_sub(i+1,j+1,array4)
#                        for x in array1:
#                            print(x)
#                        for x in array2:
#                            print(x)
#                        for x in array3:
#                            print(x)
#                        for x in array4:
#                            print(X)

    def easyType1(self):
        if self.flag == "false1":
            self.shaffuru_matrix(count=1,excption=["X1+","X1-","Y1+","Y1-","Z1+","Z1-"])
        elif self.flag == "false2":
            self.shaffuru_matrix(count=1,excption=["X1+","X1-","Y1+","Y1-","Z1+","Z1-"])
        elif self.flag == "false3":
            self.matrix_3 = copy.deepcopy(self.matrix_3_def)
            self.rotate_matrix(self.reverse_directions(self.rotated))
        elif self.flag == "true":
            self.shaffuru_matrix(count=0)
            
    def normalType1(self):
        if self.flag == "false1":
            self.shaffuru_matrix(count=1,excption=["X1+","X1-","Y1+","Y1-","Z1+","Z1-"])
        elif self.flag == "false2":
            self.shaffuru_matrix(count=1,excption=["X1+","X1-","Y1+","Y1-","Z1+","Z1-"])
        elif self.flag == "false3":
            self.matrix_3 = copy.deepcopy(self.matrix_3_def)
            self.rotate_matrix(self.reverse_directions(self.rotated))
        elif self.flag == "true":
            self.shaffuru_matrix(count=0)
        self.change_matrix()
        
    def hardType1(self):
        if self.flag == "false1":
            self.shaffuru_matrix(count=1,excption=["X1+","X1-","Y1+","Y1-","Z1+","Z1-"])
        elif self.flag == "false2":
            self.shaffuru_matrix(count=1,excption=["X1+","X1-","Y1+","Y1-","Z1+","Z1-"])
        elif self.flag == "false3":
            self.matrix_3 = copy.deepcopy(self.matrix_3_def)
            self.rotate_matrix(self.reverse_directions(self.rotated))
        elif self.flag == "true":
            self.shaffuru_matrix(count=0)
        self.change_matrix()
    
    def extraType1(self):
        if self.flag == "false1":
            self.shaffuru_matrix(count=1,excption=["X1+","X1-","Y1+","Y1-","Z1+","Z1-"])
        elif self.flag == "false2":
            self.shaffuru_matrix(count=1,excption=["X1+","X1-","Y1+","Y1-","Z1+","Z1-"])
        elif self.flag == "false3":
            self.matrix_3 = copy.deepcopy(self.matrix_3_def)
            self.rotate_matrix(self.reverse_directions(self.rotated))
        elif self.flag == "true":
            self.shaffuru_matrix(count=0)
        self.change_matrix()
        self.mask_black()
        
    def mask_black(self):
        mask_number = random.randint(1,6)
        mask_matrix = [[7]*3 for _ in range(3)]
        for i in range(4):
            for j in range(4):
                if self.geometric_net[i][j] == mask_number:
                    self.put3x3_sub(i,j,mask_matrix)

class Matrix:
    def __init__(self):
        self.question = Rubik()
        self.option1 = Rubik()
        self.option2 = Rubik()
        self.option3 = Rubik()
        self.option4 = Rubik()

        #難易度
        self.mode = "easy"
        
        #結果
        self.answer = []
        self.time = []
        
        
    def set_matrix(self):
        #pythonはすべて参照渡しのためcopyを使って値渡しにしている
        self.option1=Rubik(copy.deepcopy(self.question.matrix_3),copy.deepcopy(self.question.rotated))
        self.option2=Rubik(copy.deepcopy(self.question.matrix_3),copy.deepcopy(self.question.rotated))
        self.option3=Rubik(copy.deepcopy(self.question.matrix_3),copy.deepcopy(self.question.rotated))
        self.option4=Rubik(copy.deepcopy(self.question.matrix_3),copy.deepcopy(self.question.rotated))
        self.set_flag()
        
        #正解と間違いを決定する
    def set_flag(self):
        flag_list = ["true","false1","false2","false3"]
        random.shuffle(flag_list)
        self.option1.set_flag(flag_list[0])
        self.option2.set_flag(flag_list[1])
        self.option3.set_flag(flag_list[2])
        self.option4.set_flag(flag_list[3])
        
    def get_flag(self,index):
        if index == 1:
            return self.option1.flag
        elif index == 2:
            return self.option2.flag
        elif index == 3:
            return self.option3.flag
        elif index == 4:
            return self.option4.flag
        
    def set_result(self,answer,time):
        self.answer = answer
        self.time = time
        
    def reset(self):
        self.question.reset_matrix()
    
    def calcualtion_score(self):
        score = 0
        for i in range(5):
            if self.answer[i] == "true":
                score += 100
                if i == 0:
                    time_str = self.time[i]
                    # 分と秒に分ける
                    minutes, seconds = time_str.split(':')
                    # 秒を計算する
                    total_seconds = int(minutes) * 60 + float(seconds)
                    x = total_seconds
                else:
                    time_str1 = self.time[i]
                    time_str2 = self.time[i-1]
                    # 分と秒に分ける
                    minutes1, seconds1 = time_str1.split(':')
                    minutes2, seconds2 = time_str2.split(':')
                    # 秒を計算する
                    total_seconds1 = int(minutes1) * 60 + float(seconds1)
                    total_seconds2 = int(minutes2) * 60 + float(seconds2)
                    x = total_seconds1 - total_seconds2
                if self.mode == "easy":
                    if x > 5.0:
                        score += 100/(1.0+(x - 5.0))  # 逆数を使った緩やかな減少
                    else:
                        score += 100
                if self.mode == "normal":
                    if x > 9.0:
                        score += 100/(1.0+(x - 10.0))  # 逆数を使った緩やかな減少
                    else:
                        score += 100
                if self.mode == "hard":
                    if x > 12.0:
                        score += 100/(1.0+(x - 15.0))  # 逆数を使った緩やかな減少
                    else:
                        score += 100
                if self.mode == "extra":
                    if x > 15.0:
                        score += 100/(1.0+(x - 15.0))  # 逆数を使った緩やかな減少
                    else:
                        score += 100
        if score >= 1000:
            score = 999
        return score
    
    def easyType1(self):
        self.question.shaffuru_matrix(count=random.randint(1,2),excption=["X1+","X1-","Y1+","Y1-","Z1+","Z1-"])
        self.set_matrix()
        self.option1.easyType1()
        self.option2.easyType1()
        self.option3.easyType1()
        self.option4.easyType1()
        if self.question.matrix_3 == self.option1.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
        if self.question.matrix_3 == self.option2.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
        if self.question.matrix_3 == self.option3.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
        if self.question.matrix_3 == self.option4.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
            
    def normalType1(self):
        self.question.shaffuru_matrix(count=random.randint(1,2),excption=["X1+","X1-","Y1+","Y1-","Z1+","Z1-"])
        self.set_matrix()
        self.option1.normalType1()
        self.option2.normalType1()
        self.option3.normalType1()
        self.option4.normalType1()
        if self.question.matrix_3 == self.option1.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
        if self.question.matrix_3 == self.option2.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
        if self.question.matrix_3 == self.option3.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
        if self.question.matrix_3 == self.option4.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
            
    def hardType1(self):
        self.question.shaffuru_matrix(count=random.randint(3,7),excption=["X1+","X1-","Y1+","Y1-","Z1+","Z1-"])
        self.set_matrix()
        self.option1.hardType1()
        self.option2.hardType1()
        self.option3.hardType1()
        self.option4.hardType1()
        if self.question.matrix_3 == self.option1.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
        if self.question.matrix_3 == self.option2.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
        if self.question.matrix_3 == self.option3.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
        if self.question.matrix_3 == self.option4.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
            
    def extraType1(self):
        self.question.shaffuru_matrix(count=50,excption=["X1+","X1-","Y1+","Y1-","Z1+","Z1-"])
        self.set_matrix()
        self.option1.extraType1()
        self.option2.extraType1()
        self.option3.extraType1()
        self.option4.extraType1()
        if self.question.matrix_3 == self.option1.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
        if self.question.matrix_3 == self.option2.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
        if self.question.matrix_3 == self.option3.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)
        if self.question.matrix_3 == self.option4.matrix_3 and self.option1.flag == "false":
            self.option1.shaffuru_matrix(count=1)

def print_matrix(matrix):
    for x in matrix:
        print(x)

if __name__ == "__main__":
    test = Matrix()
    test.set_matrix()
    test.set_flag()
    test.extraType1()
    test.option1.mask_black()
    for matrix in test.option1.matrix_3_sub:
        print(matrix)
    #print(random.randint(1,6))
    
    #print(test.question.reverse_direction("X1+"))
    #print(test.question.reverse_directions(["X0+","X1+","X2+","X0-","X1-","X2-","Y0+","Y1+","Y2+","Y0-","Y1-","Y2-","Z0+","Z1+","Z2+","Z0-","Z1-","Z2-"]))