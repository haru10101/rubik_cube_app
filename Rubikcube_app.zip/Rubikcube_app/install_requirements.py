import subprocess
import sys
import importlib
import importlib.metadata  # Python 3.8 以上

# pip名 -> import名 & version
required_packages = {
    'numpy':     {'import': 'numpy', 'version': '2.1.2'},
    'pywebview': {'import': 'webview', 'version': '5.3.2'}
}

def check_and_install(pip_name, import_name, exact_version):
    try:
        importlib.import_module(import_name)  # 存在チェック

        # バージョン取得は pip パッケージ名から
        installed_version = importlib.metadata.version(pip_name)

        if installed_version != exact_version:
            print(f"{pip_name} version {installed_version} != {exact_version}, reinstalling exact version...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", f"{pip_name}=={exact_version}"])
        else:
            print(f"{pip_name} version {installed_version} is OK.")
    except ModuleNotFoundError:
        print(f"{pip_name} (import name: {import_name}) is not installed. Installing...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", f"{pip_name}=={exact_version}"])
    except importlib.metadata.PackageNotFoundError:
        print(f"{pip_name} is not found via metadata, installing...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", f"{pip_name}=={exact_version}"])

# 実行
for pip_name, info in required_packages.items():
    check_and_install(pip_name, info['import'], info['version'])

print("All required packages are exactly installed.")
