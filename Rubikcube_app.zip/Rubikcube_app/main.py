import webview
import json
import matrix

class Api:
    def __init__(self):
        self.module = matrix.Matrix()
    
    def go_to_mode(self):
        window.load_url('web/mode.html')
    
    def go_to_start(self):
        window.load_url('web/start.html')
    
    def go_to_wait(self):
        window.load_url('web/wait.html')
    
    def go_to_result(self):
        window.load_url('web/result.html')
    
    def receive_mode(self, mode):
        self.module.mode = mode
    
    def make(self):
        if getattr(self.module, "mode") == "easy":
            self.module.easyType1()
        if getattr(self.module, "mode") == "normal":
            self.module.normalType1()
        if getattr(self.module, "mode") == "hard":
            self.module.hardType1()
        if getattr(self.module, "mode") == "extra":
            self.module.extraType1()
    
    def get_flag(self,index):
        flag = self.module.get_flag(index=index)
        response = { "flag": flag}
        return json.dumps(response)
    
    def matrix_reset(self):
        self.module.reset()
    
    def print_get(self,index):
        print(index)
    
    def get_matrix(self):
        response = { "matrix": getattr(self.module.question, "matrix_3_sub"), "matrix1": getattr(self.module.option1, "matrix_3_sub"), 
                    "matrix2": getattr(self.module.option2, "matrix_3_sub"), "matrix3": getattr(self.module.option3, "matrix_3_sub"),
                    "matrix4": getattr(self.module.option4, "matrix_3_sub")}
        return json.dumps(response)
    
    def start(self):
        if getattr(self.module, "mode") == "easy":
            window.load_url('web/quiz.html')
        if getattr(self.module, "mode") == "normal":
            window.load_url('web/quiz.html')
        if getattr(self.module, "mode") == "hard":
            window.load_url('web/quiz.html')
        if getattr(self.module, "mode") == "extra":
            window.load_url('web/quiz.html')
            
    def receive_result(self,time,answer):
        self.module.set_result(answer=answer,time=time)
    
    def get_result(self):
        response = {"result": getattr(self.module, "answer"), "time": getattr(self.module, "time")}
        print(getattr(self.module, "answer"))
        print(getattr(self.module, "time"))
        return json.dumps(response)
    
    def get_score(self):
        score = {"score": self.module.calcualtion_score()}
        return json.dumps(score)
    
    def close_window(self):
        webview.windows[0].destroy()  # ウィンドウを閉じる


if __name__ == '__main__':
    api = Api()
    window = webview.create_window('ルービックキューブアプリ', 'web/start.html', js_api=api, fullscreen=True)
    webview.start(debug=False)
